﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Filters;
using Demo.WebApi.IISHosted.Models;

namespace Demo.WebApi.IISHosted.Controllers
{
    public class AwesomeController : ApiController
    {
        [HttpGet]
        public string Status()
        {
            return "Your Awesome";
        }

        [HttpPost]
        public string Status(string status)
        {
            return string.Format("Called form post - {0}", status);
        }

        [HttpPut]
        [ActionName("Status")]
        public Person Status_Put(string status)
        {
            return new Person
                {
                    FirstName = "Derik",
                    LastName = "Whittaker"
                };
        }

        //public void Status(string status)
        //{
        //    Debug.WriteLine("Inside Delete");
        //}
    }

}