﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Filters;
using Demo.WebApi.IISHosted.Models;

namespace Demo.WebApi.IISHosted.Controllers
{

    public class AwesomeController : ApiController
    {
        private readonly SomeService _someService;

        public AwesomeController(SomeService someService)
        {
            _someService = someService;
        }

        [HttpGet]
        public string Status()
        {
            return "Your Awesome";
        }

    }

    public class SomeService
    {
        public SomeService()
        {
            Id = 1;
        }
        public int Id { get; set; }
    }

}