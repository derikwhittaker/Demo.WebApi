

   ----------------------------------------------------------------------
           README file for MSIE JavaScript Engine for .NET 1.1.1

   ----------------------------------------------------------------------

          Copyright 2012 Andrey Taritsyn - http://www.taritsyn.ru
		  
		  
   ===========
   DESCRIPTION
   ===========
   This project is a .NET-wrapper for working with the Internet Explorer's 
   JavaScript engines (Chakra and Classic JavaScript Engine). 
   Project was based on part of the code of the library 
   SassAndCoffee.JavaScript (http://github.com/xpaulbettsx/SassAndCoffee).
   
   =============
   RELEASE NOTES
   =============
   Assembly MsieJavaScriptEngine.dll now signed.

   ============
   PROJECT SITE
   ============
   http://github.com/Taritsyn/MsieJavaScriptEngine