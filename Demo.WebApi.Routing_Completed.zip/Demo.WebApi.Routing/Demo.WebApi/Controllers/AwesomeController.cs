﻿using System.Web.Http;
using Demo.WebApi.IISHosted.Models;

namespace Demo.WebApi.IISHosted.Controllers
{
    public class AwesomeController : ApiController
    {
        [HttpGet]
        public string Status(int id)
        {
            return string.Format("Status was called with {0}", id);
        }

        [HttpGet]
        public string StatusAll(int id)
        {
            return string.Format("Status ALL was called with {0}", id);
        }
        
    }

}