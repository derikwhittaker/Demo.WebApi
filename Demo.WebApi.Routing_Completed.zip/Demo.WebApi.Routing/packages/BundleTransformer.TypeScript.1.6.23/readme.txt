

   ----------------------------------------------------------------------
           README file for Bundle Transformer: TypeScript 1.6.23

   ----------------------------------------------------------------------

          Copyright 2013 Andrey Taritsyn - http://www.taritsyn.ru
		  

   ===========
   DESCRIPTION
   ===========
   BundleTransformer.TypeScript contains translator-adapter 
   TypeScriptTranslator (supports TypeScript
   (http://www.typescriptlang.org) version 0.8.3). This adapter makes 
   translation of TypeScript-code to JS-code. Also contains HTTP-handler 
   TypeScriptAssetHandler, which is responsible for text output of 
   translated TypeScript-asset.
   
   =============
   RELEASE NOTES
   =============
   Added support of TypeScript version 0.8.3.

   =============
   DOCUMENTATION
   =============
   See documentation on CodePlex - 
   http://bundletransformer.codeplex.com/documentation